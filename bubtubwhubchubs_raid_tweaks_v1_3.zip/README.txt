Supports Minecraft 1.20.1
Automatically places all mobs under tag #raiders on one scoreboard team
Disables friendly fire between #raiders
Kills arrows, tipped arrows, and spectral arrows that are touching the ground to reduce lag during modded/vanilla raids
No configuration required
Multiplayer compatible
Negligible performance impact