# Gives each not-yet-tracked evoker the first free slot_N tag (N = 1..8).
# "has_slot" marks an evoker as already claimed a slot so it isn't reassigned.
execute as @e[type=evoker,tag=!has_slot] unless entity @e[type=evoker,tag=slot_1] run tag @s add slot_1
execute as @e[type=evoker,tag=slot_1,tag=!has_slot] run tag @s add has_slot

execute as @e[type=evoker,tag=!has_slot] unless entity @e[type=evoker,tag=slot_2] run tag @s add slot_2
execute as @e[type=evoker,tag=slot_2,tag=!has_slot] run tag @s add has_slot

execute as @e[type=evoker,tag=!has_slot] unless entity @e[type=evoker,tag=slot_3] run tag @s add slot_3
execute as @e[type=evoker,tag=slot_3,tag=!has_slot] run tag @s add has_slot

execute as @e[type=evoker,tag=!has_slot] unless entity @e[type=evoker,tag=slot_4] run tag @s add slot_4
execute as @e[type=evoker,tag=slot_4,tag=!has_slot] run tag @s add has_slot

execute as @e[type=evoker,tag=!has_slot] unless entity @e[type=evoker,tag=slot_5] run tag @s add slot_5
execute as @e[type=evoker,tag=slot_5,tag=!has_slot] run tag @s add has_slot

execute as @e[type=evoker,tag=!has_slot] unless entity @e[type=evoker,tag=slot_6] run tag @s add slot_6
execute as @e[type=evoker,tag=slot_6,tag=!has_slot] run tag @s add has_slot

execute as @e[type=evoker,tag=!has_slot] unless entity @e[type=evoker,tag=slot_7] run tag @s add slot_7
execute as @e[type=evoker,tag=slot_7,tag=!has_slot] run tag @s add has_slot

execute as @e[type=evoker,tag=!has_slot] unless entity @e[type=evoker,tag=slot_8] run tag @s add slot_8
execute as @e[type=evoker,tag=slot_8,tag=!has_slot] run tag @s add has_slot

# If more than 8 evokers are ever alive at once, the 9th+ won't get a slot,
# so its vexes won't be linked. Copy the two-line pattern above with slot_9,
# slot_10, etc. if you need more headroom.
