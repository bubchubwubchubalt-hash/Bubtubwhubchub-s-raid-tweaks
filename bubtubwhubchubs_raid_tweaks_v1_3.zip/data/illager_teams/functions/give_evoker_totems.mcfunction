# Gives every evoker a Totem of Undying in its offhand, once.
# Mobs holding a totem in hand get the same death-protection as players.
execute as @e[type=evoker,tag=!has_totem] run item replace entity @s weapon.offhand with minecraft:totem_of_undying
execute as @e[type=evoker,tag=!has_totem] run tag @s add has_totem

# NOTE: this is single-use, same as a player's totem - once it pops, it's gone.
# To make it auto-refill after every save instead, delete the "has_totem" tag
# checks above and replace with an offhand-empty check, e.g.:
#   execute as @e[type=evoker] unless entity @s[nbt={HandItems:[{},{id:"minecraft:totem_of_undying"}]}] run item replace entity @s weapon.offhand with minecraft:totem_of_undying
